const express = require('express');
const router = express.Router();

const util = require('util')
const chance = require('chance')
const faker = require('faker')
 

/* GET home page. */
router.get('/', (req, res) => {
	res.render('index', 
	  	{ team:  'RybinSvyatoslav', 
	  	  year: 2030,
	  	  version: "3.3.3"
	  	});

  
});

module.exports = router;
