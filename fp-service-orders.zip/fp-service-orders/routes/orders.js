const express = require('express');
const router = express.Router();

const jsf = require('json-schema-faker');
const util = require('util')
const chance = require('chance')
const faker = require('faker')
jsf.extend('chance', () => new chance.Chance());
jsf.extend('faker', () => faker);

var recentDays = 5;

var schema = {
  "type": "array",
  "minItems": 10,
  "maxItems": 20,
  "items": {
	  "type": "object",
	  "properties": {
	    "email": {
	      "type": "string",
	      "faker": "internet.email"
	    },
	    "date": {
	      "type": "string",
	      "faker": "date.recent"
	    },
	    "rank" : {
	      "type": "integer", 
	       "minimum": 4,
  		   "maximum": 5
	    },
	    "number" : {
	    	"type": "string",
	        "faker": "phone.phoneNumber"
	    		 
	    	}
	    
	  },
	  "required": [
	    "email",
	    "number", 
	    "date",
	    "rank"
	   ]
	  }
};

/* GET home page. */
router.get('/', (req, res) => {

  jsf.resolve(schema).then(sample => {
  	   console.log(util.inspect(sample, 
  	   	{showHidden: false, depth: null}));
	   
	   res.render('orders', 
	  	{  orders:  sample });
  });

  
});

module.exports = router;
